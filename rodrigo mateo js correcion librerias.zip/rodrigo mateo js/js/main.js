const btn= document.querySelector('#myBtn')
btn.addEventListener('click', ()=> {
  swal("En las eras pasadas los mejores artistas marciales se debaten en combates singulares, elige tu ho morador del ciberespacio, que artista representa tu poder. Elige uno de los heroes de las fotos, escoje sabiamene...");
});

function boton(){
  const combos = tomarDato();
  let combinacion=document.getElementById("combinacion");
  console.log(combos);
  
  //local storage//
  localStorage.setItem("golpes",combos);
  const Grancomb=localStorage.getItem("golpes");
  combinacion.innerText=(Grancomb);
  
  
  
  //captura de datos//
function tomarDato() {
  let jugElegido = document.getElementById("jugador");
  let golpe1 = document.getElementById("golpe1");
  let golpe2 = document.getElementById("golpe2");
  let golpe3 = document.getElementById("golpe3");
  let sal=document.getElementById("salida");
  sal.innerHTML=jugElegido.value +"<br>" +golpe1.value + "<br>"+golpe2.value + "<br>"+golpe3.value + "<br>";
  let carga=jugElegido.value;
  let puño=golpe1.value;
  let patadas=golpe2.value;
  let codo=golpe3.value;
  const combos=[carga, puño, patadas, codo];
  return combos;
 
}

//matematica de fuerza//
const golpeComun= 200;
const golpeLargo= 100;
const patadaLarga= 150;
function golpePuño(){
  let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
  return golpe
}
function patada(){
  let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
  return golpe
}
function combo(){
  let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
    return golpe
        }
        //usuarios que usan las funciones//
        let usuario2=   golpePuño() + patada() +" "+ combos[0] ;
        let momia= golpePuño() + combo();
        let rodrigo = combo() + patada();
        
        //mostrar resultados//
        const grupoJug = {
          nombre1:"bruce",
          nombre2:"daniel",
          nombre3:"seagal", 
          nombre4:"vandame",
          nombre5:"miyagi",
          nombre6:"martin",
        }
        setTimeout(()=>{

          combinacion.innerHTML=(combos[0]==grupoJug.nombre1)?("<img src='./imagenes/bruci.png' width='100'/>"  + usuario2 ):
          combinacion.innerHTML=(combos[0]==grupoJug.nombre2)?("<img src='./imagenes/danielsan.jpg' width='100'/>"  + usuario2):
          combinacion.innerHTML=(combos[0]==grupoJug.nombre3)?("<img src='./imagenes/seagal.png' width='100'/>" + usuario2):
          combinacion.innerHTML=(combos[0]==grupoJug.nombre4)?("<img src='./imagenes/vanDame.jpg' width='100'/>" + usuario2):
          combinacion.innerHTML=(combos[0]==grupoJug.nombre5)?("<img src='./imagenes/pat.jpg' width='100'/>" + usuario2):
          combinacion.innerHTML=(combos[0]==grupoJug.nombre6)?("<img src='./imagenes/martin.jpg' width='100'/>" + usuario2):("Elegi a tu estrella marcial")
},2000);
let cont1=document.getElementById("cont1");
setTimeout(()=>{
        cont1.innerHTML=( "Momia Blanca" + " " +momia +" " +("<img src='./imagenes/momia.jpeg' width='80'/>" ));
},4000);
        let cont2=document.getElementById("cont2");
        setTimeout(()=>{
        cont2.innerHTML=("Rodrigo" +" "+ rodrigo +" "+( "<img src='./imagenes/Rodrigo.jpg' width='200'/>") );
        },6000);
        
      }