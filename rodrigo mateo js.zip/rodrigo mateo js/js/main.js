let getData= function(){
let jugador = document.getElementById("name").value;
let golpe = document.getElementById("golpe").value;
if (jugador ==""){ 
  document.getElementById("name").focus();
} else { 
   if (golpe ==""){
  document.getElementById("golpe").focus();
} else {
  console.log(jugador + " " + golpe);
  document.getElementById("name").value ="";
  document.getElementById("golpe").value ="";
  document.getElementById("name").focus();
}
  }
}

const combos = [];
let cantidad = 3
do 
 {
   let golpes = prompt("escribe el golpe");
   console.log(golpes);
   combos.push(golpes);
 } while (combos.length <=cantidad);
 console.log(combos);
 

function personaje(){
let eleccion = prompt("elegir tu estrella de accion");
alert(eleccion +" " + combos);
return eleccion;

}
const golpeComun= 200;
const golpeLargo= 100;
const patadaLarga= 150;
function golpePuño(){
let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
return golpe
}
function patada(){
    let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
    return golpe
    }
    function combo(){
        let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
        return golpe
        }
  let usuario= golpePuño() + patada() + " " + personaje();
let momia= golpePuño() + combo();
let Rodrigo =golpePuño() + combo() + patada();

console.log(`poder ${usuario} ${combos[2]} `); 
console.log(`poder momia blanca ${momia}`); 
console.log(`poder Rodrigo ${Rodrigo}`);
const ganador =combos.concat("mucha suerte", "vuelve a jugar",usuario);
console.log(ganador);



