
let jugElegido = document.getElementById("jugador");
let golpe1 = document.getElementById("golpe1");
let golpe2 = document.getElementById("golpe2");
let golpe3 = document.getElementById("golpe3");
let sal=document.getElementById("salida");

//captura de datos//
 function capturar() {
 sal.innerHTML=jugElegido.value +"<br>" +golpe1.value + "<br>"+golpe2.value + "<br>"+golpe3.value + "<br>";
   let carga=jugElegido.value;
   let puño=golpe1.value;
   let patadas=golpe2.value;
   let codo=golpe3.value;
   const combos=[carga, puño, patadas, codo];
   for( i=0; i<combos.length; i+=1){
     console.log(combos)
    }
  }
  let usuario=capturar();
  //matematica de fuerza//
const golpeComun= 200;
const golpeLargo= 100;
const patadaLarga= 150;
function golpePuño(){
let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
return golpe
}
function patada(){
    let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
    return golpe
    }
    function combo(){
        let golpe = Math.ceil (Math.random()*(golpeComun - golpeLargo) + patadaLarga);
        return golpe
        }
//usuarios que usan las funciones//
  let usuario2= golpePuño() + patada() + usuario;
let momia= golpePuño() + combo();
let Rodrigo =golpePuño() + combo() + patada();
//mostrar resultados//
console.log(`poder ${usuario2} `); 
console.log(`poder momia blanca ${momia}`); 
console.log(`poder Rodrigo ${Rodrigo}`);
//const ganador =combos.concat("mucha suerte", "vuelve a jugar",usuario);
      